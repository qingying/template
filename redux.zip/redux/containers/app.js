import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { xxx } from '../actions/indexActions';
import Loading from '../../../components/loading';
import Error from '../../../components/error';
import Page from '../components/page';
import cn from 'classnames';

const httpurl = window.lib.takeout;
const env = window.lib.env;
const native = window.takeout.jsBridge;

class App extends Component {
  componentDidMount(){
    
  }
  getPageContent() {
    const { pageConfig} = this.props;
    if (pageConfig.status == 'loading') {
      return <Loading />
    } else if (pageConfig.status == 'render') {
      return <Page ></Page>
    } else {
      return <Error type={pageConfig.errorType}/>
    }
  }

  render() {
    return (
      <div className={cn("page-wrap")}>
        {this.getPageContent()}
      </div>
    )
  }
}

function mapStateToProps(state) {
  return state;
}

export default connect(
  mapStateToProps
)(App);

