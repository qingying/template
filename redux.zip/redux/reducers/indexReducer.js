import * as types from '../constants/ActionTypes';
import { combineReducers } from 'redux';
const httpurl = window.lib.httpurl;
const native = window.takeout.jsBridge;

const initialState =
  {
    pageConfig: {
      status: initStatus,//loading,render,error,waiting:付款成功等待状态
      errorType: '',//noLogin
    },
  };



function pageConfig(state = initialState.pageConfig, action) {
  switch (action.type) {
    case types.CHANGE_PAGE_STATUS:
      return Object.assign({},state,action);
    default:
      return state;
  }
}

const rootReducer = combineReducers({
  pageConfig
});

export default rootReducer;
