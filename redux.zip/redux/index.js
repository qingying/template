import takeout from '../../common/common';
// require('../../../css/pages/xxx/index.scss');
import React from 'react';
import {render} from 'react-dom';
import {Provider} from 'react-redux';
import App from './containers/App';
import configureStore from './store/configureStore';
import env from '@ali/lib-env';
const store = configureStore();
render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('react-wrap')
);
