import mtop from '@ali/lib-mtop';
var Mtop = mtop;

class MtopCommon {
  static request(config, data = {}, errTxt) {
    config.data = Object.assign(config.data||{}, data);
    let promise = new Promise(function (resolve, reject, defaultErrorTxt) {
      let p = Mtop.request(config);
      p.then(function (mtopRes) {
        if (mtopRes.retType == Mtop.RESPONSE_TYPE.SUCCESS) {
          resolve(mtopRes);
        } else {
          // alert('defaultErrorTxt')
          mtopRes.errorInfo = Mtop.getError(mtopRes.ret)[0];
          reject(mtopRes);
        }
      }).catch(function (error) {
        //common error handle here
        error = error || {};
        error.errorInfo = Mtop.getError(error.ret)[0];
        reject(error);
      });
    });
    return promise;
  }
}


export default MtopCommon;

(function (win, lib) {
  var mtop = lib.mtop || (lib.mtop = {});

  var ERROR_MAP = {
    'FAIL_SYS_SESSION_EXPIRED': {
      message: 'SESSION失效'
    },
    'FAIL_SYS_TOKEN_EMPTY': {
      message: '令牌为空'
    },
    'FAIL_SYS_TOKEN_ILLEGAL': {
      message: '非法令牌'
    },
    'FAIL_SYS_TOKEN_EXOIRED': {
      message: '令牌过期'
    },
    'FAIL_SYS_ILLEGAL_ACCESS': {
      message: '非法请求'
    },
    'FAIL_SYS_API_STOP_SERVICE': {
      message: '应用访问的api暂停服务'
    },
    'FAIL_SYS_FLOWLIMIT': {
      message: '哎呦喂，被挤爆啦，请稍后重试'
    },
    'FAIL_LOCAL_ERROR_FANG_XUE_FENG': {
      message: '哎呦喂，被挤爆啦，请稍后重试'
    },
    'FAIL_SYS_TRAFFIC_LIMIT': {
      message: '哎呦喂，被挤爆啦，请稍后重试'
    },
    'FAIL_SYS_SM_ODD_REQUEST': {
      message: '您的请求被检查出存在异常行为'
    },
    'FAIL_SYS_SERVLET_ASYNC_START_FAIL': {
      message: 'SERVLET异步启动失败'
    },
    'FAIL': {
      message: '接口不存在/缺少必填的参数/参数格式不正确'
    },
    'FAIL_SYS_HSF_NOTFOUND': {
      message: '服务不存在/抱歉，网络系统异常'
    },
    'FAIL_SYS_SERVLET_ASYNC_TIMEOUT': {
      message: 'SERVLET异步服务超时'
    },
    'FAIL_SYS_HSF_TIMEOUT': {
      message: '抱歉，网络系统异常'
    },
    'FAIL_SYS_HSF_INVOKE_ERROR': {
      message: 'HSF执行错误/抱歉，网络系统异常'
    },
    'FAIL_SYS_SERVLET_ASYNC_ERROR': {
      message: 'SERVLET异步服务异常'
    },
    'FAIL_SYS_HSF_THROWN_EXCEPTION': {
      message: '抱歉，网络系统异常'
    },
    'FAIL_SYS_USER_VALIDATE': {
      message: '需要用户验证'
    },
    'RGV587_ERROR': {
      message: '请刷新页面，输入验证码证明咱是正常人'
    }
  };

  function getError(error) {
    // var code;
    var errorType = '';
    if (error instanceof Array) {
      error = error.map(function (err) {
        return getErrorItem(err);
      });
    } else {
      error = [getErrorItem(error)]
    }
    return error;
    function getErrorItem(error) {
      var matched;
      var code;
      var message;
      if ((matched = error.match(/([^:]+)\:\:([^:]+)/))) {
        code = matched[1];
        message = matched[2];
      } else {
        code = error;
      }
      if (ERROR_MAP[code]) {
        message = ERROR_MAP[code].message;
      } else {
        message = message || '';
      }
      if (/FAIL_SYS_SESSION_EXPIRED/.test(code) || /ERR_SID_INVALID/.test(code) || /ERRCODE_AUTH_REJECT/.test(code)) {
        errorType = 'noLogin';
      }
      if (/FAIL_SYS_FLOWLIMIT|FAIL_LOCAL_ERROR_FANG_XUE_FENG|FAIL_SYS_TRAFFIC_LIMIT/.test(code)) {
        errorType = 'limit';
      }
      return {
        errorCode: code,
        errorMessage: message,
        errorType: errorType
      };
    }
  }

  mtop.getError = getError;

})(window, window['lib'] || (window['lib'] = {}));
