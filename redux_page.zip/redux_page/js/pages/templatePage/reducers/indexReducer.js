import * as types from '../constants/ActionTypes';
import { combineReducers } from 'redux';
const httpurl = window.lib.httpurl;

const initialState =
  {
    pageConfig: {
      status: 'render',//loading,render,error,waiting:付款成功等待状态
      errorType: '',//noLogin
    },
  };



function pageConfig(state = initialState.pageConfig, action) {
  debugger;
  switch (action.type) {
    case types.CHANGE_PAGE_STATUS:
      return Object.assign({},state,action.data);
    default:
      return state;
  }
}

const rootReducer = combineReducers({
  pageConfig
});

export default rootReducer;
