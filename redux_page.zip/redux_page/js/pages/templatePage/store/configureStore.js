import {createStore, applyMiddleware} from 'redux';
import thunkMiddleware from 'redux-thunk';
import createLogger from 'redux-logger';
import rootReducer from '../reducers/indexReducer.js';

export default function configureStore(preloadedState) {
  const store = createStore(
    rootReducer,
    window.devToolsExtension && window.devToolsExtension(),
    applyMiddleware(thunkMiddleware, createLogger()),
    preloadedState
  );

  if (module.hot) {
    // Enable Webpack hot module replacement for reducers
    module.hot.accept('../reducers/indexReducer.js', () => {
      debugger;
      const nextReducer = require('../reducers/indexReducer.js').default;
      store.replaceReducer(nextReducer);
    });
  }

  return store;
}
