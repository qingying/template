import * as types from '../constants/ActionTypes';
import mtopCommon from '../../../common/mtopCommon';

export function getPageData() {
	return (dispatch, getState) => {
		mtopCommon.request({
			api: '',
			v: '1.0',
			data: {},
			ecode: 1,
			dataType: 'originaljsonp'
		},(response) => {

		}, (response) => {
			let { errorType, message } = dealErrorInfo(response);
			// return dispatch({
			// 	type: types.CHANGE_PAGE_STATUS,
			// 	status: 'error',
			// 	errorType: errorType,
			// 	errorText: message
			// })
		})
	}
}

function dealErrorInfo(response, autoLogin = false) {
	let errorInfo = response && response.errorInfo;
	errorInfo = errorInfo || {};
	let errorType = errorInfo.errorType;
	let code = errorInfo.errorCode;
	let message = '网络异常，请稍后重试';
	if (errorType == 'noLogin' && autoLogin) {
		message = '请登录';
		login.goLoginAsync(function(status) {
			if (status && status == 'SUCCESS') {
				dispatch({
					type: types.CHANGE_PAGE_STATUS,
					status: 'loading'
				})
				dispatch(getPageData());
			}
		})
	} else if (code == 'FAIL_SYS_TRAFFIC_LIMIT' || code == 'FAIL_LOCAL_ERROR_FANG_XUE_FENG') {
		message = errorInfo.errorMessage;
	}
	return {
		errorType,
		message
	}
}

export function getConfig() {
	return (dispatch) => {
		util.getMtConfig({
			// testSrc: '//mt2.alibaba-inc.com/core/data/dataEntityMock.do?spm=a1z3i.a4.0.0.biT6O9&id=22399',
			// onlineSrc: '//huodong.m.taobao.com/api/data/v2/443840572a8a4eb4921294351ea80bd1.js'
		}).then(()=> {
			// dispatch({
			// 	type: types.UPDATE_MT_CONFIG,
			// 	data: window.vipCardConfig
			// })
		},() => {

		})
	}
}

export function changePageStatus(status) {
	return (dispatch) => {
		dispatch({
			type: types.CHANGE_PAGE_STATUS,
			data: status
		})
	}
}