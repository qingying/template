import { Component, PropTypes } from 'react';
import { changePageStatus } from '../actions/indexActions';

export default class Page extends Component {
  changePageStatus() {
    this.props.dispatch(changePageStatus('loading'))
  }
	render() {
		return <div>
			<p onClick={() => this.changePageStatus()}>hello world</p>
		</div>
	}
}