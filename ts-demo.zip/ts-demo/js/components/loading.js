/*
loading组件
*/
require('../../css/components/loading.scss');
import { Component } from 'react';
class loading extends Component {
    render(){
        return (
            <div className="loading-wrap">
                <p className="loading">
                    <span className="icon"></span>
                    <span>加载中</span>
                </p>
            </div>
        )
    }
}

export default loading;
