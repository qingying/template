// todo 同loading
/*
    可配置参数
    图片
    文本
    按钮
*/
require('../../css/components/error.scss');
import { Component } from 'react';

class error extends Component {
    refresh(){
        window.location.reload();
    }
    goLogin(){
        
    }
    render(){
        let type = this.props.type;
        let text = this.props.text
        if (type == 'noLogin') {
            return (
                <div className="error-wrap">
                    <div className="error">
                        <p className="icon"></p>
                        <div className="tip-wrap">
                            <p className="tip">{'请登录' || '请登录后查看收货地址'}</p>
                        </div>
                        <p className="btn" onClick={this.goLogin}>登录</p>
                    </div>
                </div>
            )
        } else {
            return (
                <div className="error-wrap">
                    <div className="error">
                        <p className="icon"></p>
                        {
                            text ? <div className="tip-wrap"><p className="tip">{text}</p></div>
                            :  <div className="tip-wrap">
                                    <p className="tip">网络异常哦~</p>
                                    <p className="tip">请再刷新看看~</p>
                                </div>
                        }
                        <p className="btn" onClick={this.refresh}>再次刷新</p>
                    </div>
                </div>
            )
        }
    }
}

export default error;
