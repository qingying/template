##  项目介绍

### 准备工作 

host绑定： 127.0.0.1 takeout.wapa.taobao.com  
全局安装[or-awp](http://web.npm.alibaba-inc.com/package/or-awp),并配置好
安装依赖包: npm run install

### 本地开发
sudo npm start

### 打包&发布

js&css: npm run build 
html: npm run html(发布日常&预发 npm run html-dev) 
发布js&css资源上线 
发布html文件awp： npm run publish-m(日常：npm run publish-waptest 预发: npm run publish-wapa)
发布html文件到mt: 将awp目录下的页面内容拷贝到mt
