import * as React from 'react'
import { observer, inject } from 'mobx-react'
import { Location } from './stores/location'
import Index from './pages/index/page'

interface injectedProps {
    location: Location
}


@inject("location")
@observer export default class PageRoute extends React.Component<null, null> {
  private get injected() {
        return this.props as injectedProps
  }
  render() {
    let { location } = this.injected
    let { matchedRuleName, params } = location
    switch( matchedRuleName ) {
      case 'index':
        return <Index params={params}></Index>
      default:
        return null;
    }
  }
}
