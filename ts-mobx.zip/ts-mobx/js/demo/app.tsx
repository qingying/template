import * as React from 'react';
import { Provider } from 'mobx-react';
import stores from './stores';
import PageRoute from './pageRoute';

const app = props => <Provider {...stores}>
  <PageRoute />
</Provider>

export default app
