import * as React from 'react'

interface InavBarProps {
  active: string
}

interface InavItem {
  name: string
  key: string
  icon: string
  path: string
}

export default class NavBar extends React.Component<InavBarProps, null> {
  private navData: Array<InavItem> = [
    {
      name: '主页',
      key: 'home',
      icon: '',
      path: '/home'
    },
    {
      name: '战队',
      key: 'crowd',
      icon: '',
      path: '/crowd'
    },
    {
      name: '悬赏',
      key: 'task',
      icon: '',
      path: '/task'
    },
  ]
  navClick(index) {
    let item = this.navData[index];
    if (item.key != this.props.active) {
      (window as any).virtualRoute.replace(item.path)
    }
  }
  render() {
    return <div>
      {
        this.navData.map((item, index) => {
          return <p key={index} onClick={(e) => this.navClick(index)}>{item.name}</p>
        })
      }
    </div>
  }
}