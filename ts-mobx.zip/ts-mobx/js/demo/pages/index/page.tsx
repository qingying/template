import * as React from 'react'
import NavBar from './navBar'
import Crowd from './crowd'
import Task from './task'
import Home from './home'

interface IpageProps {
  params: any
}

export default class Page extends React.Component<IpageProps, null> {
  renderContent(tabName: string) {
    switch(tabName) {
      case 'crowd':
        return <Crowd></Crowd>
      case 'task':
        return <Task></Task>
      default:
        return <Home></Home>
    }
  }
  render() {
    let { params } = this.props;
    let { tabName } = params;
    return <div>
      {this.renderContent(tabName)}
      <NavBar active={tabName}></NavBar>
    </div>
  }
}