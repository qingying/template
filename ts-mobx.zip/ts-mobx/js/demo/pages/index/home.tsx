import * as React from 'react'
import { observer, inject } from 'mobx-react'
import { home } from '../../stores/home'

interface injectedProps {
    home: home
}

@inject('home')
@observer
export default class Home extends React.Component<null,null> {
  private get injected() {
    return this.props as injectedProps
  }
  componentDidMount() {
    let { home } = this.injected
    if (!home.dataReady) {
      this.injected.home.getHomeData()
    }
  }
  render() {
    let { bannerList=[], gameDetailList=[]} = this.injected.home
    return <div className="page home">
      {
        bannerList.map((item, index) => <p key={index}>{item.pic}</p>)
      }
      {
        gameDetailList.map((item, index) => {
          let { id, baseInfo } = item
          let { name, typeName, miniPic, playPeople, season } = baseInfo
          return <div key={index}>
            <p>{id}</p>
            <p>{name}</p>
            <p>{typeName}</p>
            <p>{miniPic}</p>
            <p>{playPeople}</p>
            <p>{season}</p>
          </div>
        })
      }
    </div>
  }
}