import * as React from 'react'


export default class Task extends React.Component<null, null> {
  render() {
    return <div>
      悬赏任务
    </div>
  }
}