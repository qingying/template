import * as React from 'react'
import { observer, inject } from 'mobx-react'
import { crowdPage } from '../../stores/crowdPage'


interface injectedProps {
  crowdPage: crowdPage
}

@inject('crowdPage')
@observer
export default class Crowd extends React.Component<null, null> {
  private get injected() {
    return this.props as injectedProps
  }
  componentDidMount() {
    let { crowdPage } = this.injected
    if (!crowdPage.dataReady) {
      this.injected.crowdPage.getCrowdList()
    }
  }
  render() {
    return <div>
      {
        this.injected.crowdPage.crowdList.map((item, index) => {
          let { id, name, icon, score, num, limitNum, gameId} = item
          return <div key={id}>
            <p>{name}</p>
            <p>{icon}</p>
            <p>{score}</p>
            <p>{num}</p>
            <p>{limitNum}</p>
            <p>{gameId}</p>
          </div>
        })
      }
    </div>
  }
}