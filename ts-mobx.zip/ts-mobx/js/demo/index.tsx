import '../../css/pages/gameMachine/index.scss';
import * as React from 'react';
import * as ReactDom from 'react-dom';
import { useStrict } from 'mobx'
import App from './app';

useStrict(true);

ReactDom.render(
<App />,
document.getElementById('react-wrap')
)

if (module.hot) {
  module.hot.accept('./app', () => {
    const NextRootContainer = require('./app').default;
    ReactDom.render(<NextRootContainer />, document.getElementById('react-wrap'));
  })
  module.hot.accept('./stores/index.ts', () => {
    const NextRootContainer = require('./app').default;
    ReactDom.render(<NextRootContainer />, document.getElementById('react-wrap'));
  })
}
