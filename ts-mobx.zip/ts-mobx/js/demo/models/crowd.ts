export default class crowd {
  id: string //战队id
  name: string //战队名称
  icon: string //战队图标
  limitNum?: string = '20'//群成员上限
  num: string //战队成员人数
  gameId: string //对应的游戏id
  score?: string //战队得分
  level?:string //战队排名
}

class 