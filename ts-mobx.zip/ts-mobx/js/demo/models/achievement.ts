export default class Iachievement {
  id: string //成就id
  pic: string //成就图片
  title: string //成就标题
  desc: string //成就描述
  status: number //是否获得成就 0未获得 1已获得
}