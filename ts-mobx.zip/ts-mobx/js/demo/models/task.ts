export default class Itask {
  id: string //任务id
  title: string //任务名称
  desc: string //任务描述
  pic: string//任务图片
  status: number //任务状态：-1未加入战队，0未揭榜,1已揭榜,2已完成任务,3已领取奖励
  gameId: string //对应游戏id
  start: string //开始时间
  end: string //结束时间
}