import Itask from './task'
import Iachievement from './achievement'
class IbaseInfo {
  // base info
  name: string //游戏名称
  typeId: string //游戏类型id
  typeName: string //游戏类型名称
  desc: string //游戏详情文字描述
  miniPic: string //游戏小图
  bannerPic: Array<string> //游戏大图描述

  // server info
  playPeople: string //多少人在玩
  season: boolean //是否赛季中
  hasCrowd?: boolean //是否有加入相关群
}
export default class IgameDetail {
  id: string //游戏ID

  baseInfo: IbaseInfo

  tasks: Array<Itask>

  achievements: Array<Iachievement>

}