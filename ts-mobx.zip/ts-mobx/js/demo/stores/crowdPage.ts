import {observable, computed, action} from 'mobx'
import crowd from '../models/crowd'
import mtopCommon from '../../common/mtopCommon'

export class crowdPage {
  public dataReady: boolean = false
  @observable crowdList: Array<crowd> = []

  @action 
  public getCrowdList() {
    console.log('getCrowdList')
    this.crowdList = [
      {
        id: '123',
        name: '保卫萝卜',
        icon: '',
        score: '111',
        num: '5',
        gameId: '1' 
      }
    ];
    this.dataReady = true;
  }
}

export default new crowdPage()