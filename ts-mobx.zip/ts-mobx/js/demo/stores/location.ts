import VirtualRoute from '@ali/virtual-route'
import {observable, computed, action} from 'mobx'

const virtualRoute = new VirtualRoute([
  {
    ruleName: 'index',//主页面
    rule: '/:tabName'
  },
  {
    ruleName: 'gameDetail',//游戏详情
    rule: '/gameDetail/:gameId@?tabName'
  },
  {
    ruleName: 'topList',//榜单
    rule: '/gameDetail/:gameId'
  },
  {
    ruleName: 'achievementDetail',//成就详情
    rule: '/achievementDetail/:achievementId'
  },
  {
    ruleName: 'person',//个人页
    rule: '/person'
  },
  {
    ruleName: 'addCrowd',//创建战队
    rule: '/addCrowd'
  },
  {
    ruleName: 'crowdDetail',//战队详情
    rule: '/crowdDetail/:crowId'
  },
  {
    ruleName: 'crowdDeletePeople',//删除成员
    rule: '/crowdDeletePeople/:crowId'
  },
  {
    ruleName: 'crowdAddPeople',//添加成员
    rule: '/crowdAddPeople/:crowId'
  },
]);

export class Location {
  @observable public  isMatched: string

  @observable public params: any

  @observable public matchedRuleName: string

  constructor() {
    this.setLocation()
  }

  @action 
  public setLocation() {
    this.isMatched = virtualRoute.location.isMatched
    this.params = virtualRoute.location.params
    this.matchedRuleName = virtualRoute.location.matchedRuleName
  }
}

let location = new Location();

document.addEventListener('hashchange', () => {
  location.setLocation()
}, false)

;(window as any).virtualRoute = virtualRoute;
export default location