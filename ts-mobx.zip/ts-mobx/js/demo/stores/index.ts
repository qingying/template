import location from './location';
import home from './home';
import crowdPage from './crowdPage';

let stores = {
  location,
  home,
  crowdPage
}
export default stores
