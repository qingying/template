import {observable, computed, action} from 'mobx'
import IgameDetail from '../models/gameDetail'
import mtopCommon from '../../common/mtopCommon'

interface Ibanner {
  pic: string, //banner 图片
  link: string, //banner 链接
}


export class home {
  public dataReady: boolean = false
  @observable public bannerList: Array<Ibanner> = []
  @observable public gameDetailList: Array<IgameDetail> = []

  @computed public get gameDetailObj() {
    let obj = {}
    this.gameDetailList && this.gameDetailList.map((item) => {
      obj[item.id] = item
    })
    return obj
  }

  @action
  public getHomeData() {
    console.log('getHomeData')
    this.dataReady = true
    let bannerItem = {
        pic: '//img.alicdn.com/tfs/TB1ClEwXmFRMKJjy0FhXXX.xpXa-520-280.jpg_q90_.webp',
        link: '//h5.m.taobao.com'
      }
    let list = []
    for (let i = 0; i < 3; i++) {
      list.push(bannerItem)
    }
    this.bannerList = list

    this.gameDetailList = [
      {
        id: '1',
        baseInfo: {
          name: '保卫萝卜',
          typeId: '',
          typeName: '',
          desc: '',
          miniPic: '',
          bannerPic: [''],
          playPeople: '',
          season: false
        },
        achievementList: [
          {
            pic: '//gw.alicdn.com/bao/uploaded/TB1ROMiLpXXXXX5XFXXhB9v1VXX-216-230.png',
            title: '',
            desc: '',
            status: 0
          }
        ],
        task: [
          {
            title: '',
            desc: '',
            pic: '',
            status: 0
          }
        ]
      }
    ]
    // mtopCommon.request({
    //   api: '',
    //   v: '',
    //   data: {

    //   }     
    // }).then((response) => {

    // }, (response) => {

    // })
  }
}

export default new home()